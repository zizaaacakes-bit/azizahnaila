import pg from 'pg';
const {Pool}=pg;
let pool;
export function db(){if(!pool){const url=process.env.NETLIFY_DATABASE_URL||process.env.DATABASE_URL;if(!url)throw new Error('NETLIFY_DATABASE_URL belum dikonfigurasi');pool=new Pool({connectionString:url,ssl:url.includes('localhost')?false:{rejectUnauthorized:false},max:5});}return pool;}
export const json=(statusCode,body)=>({statusCode,headers:{'Content-Type':'application/json','Cache-Control':'no-store','Access-Control-Allow-Origin':'same-origin'},body:JSON.stringify(body)});
export function userFrom(event){return event.clientContext?.user||null;}
export async function requireFinance(event){const user=userFrom(event);if(!user?.email)throw Object.assign(new Error('Silakan login menggunakan Netlify Identity.'),{status:401});const email=user.email.toLowerCase();const admin=(process.env.ADMIN_EMAIL||'').toLowerCase();if(admin&&email===admin)return {email,name:user.user_metadata?.full_name||email,role:'admin'};const r=await db().query('SELECT email,name,role FROM finance_team_members WHERE lower(email)=$1',[email]);if(!r.rowCount)throw Object.assign(new Error('Akun ini belum diberi akses tim Finance.'),{status:403});return {email,name:r.rows[0].name||email,role:r.rows[0].role};}
export function method(event,m){if(event.httpMethod!==m)throw Object.assign(new Error('Method tidak diizinkan.'),{status:405});}
