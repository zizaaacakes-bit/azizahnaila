# Petty Cash — deploy + dashboard admin

Project ini mempertahankan file frontend hasil deploy yang diberikan (bundle React/CSS asli), lalu menambahkan halaman admin dan endpoint backend untuk membaca serta memperbarui status pengajuan.

## Struktur
- `public/` — frontend hasil deploy asli dan halaman `admin.html` baru.
- `netlify/functions/requests-list.mjs` — daftar pengajuan untuk anggota Finance.
- `netlify/functions/request-update.mjs` — perubahan status, nominal disetujui, dan pesan kepada pemohon; mencatat audit trail.
- `netlify/database/migrations/001_petty_cash.sql` — skema database.

## Deploy ke GitHub dan Netlify
1. Buat repository GitHub baru dan upload seluruh isi folder project ini.
2. Di Netlify pilih **Add new site → Import an existing project** lalu pilih repository tersebut.
3. Aktifkan Netlify Identity pada **Site configuration → Identity**. Aktifkan registrasi hanya sesuai kebutuhan; jangan biarkan publik mendaftar sebagai anggota Finance.
4. Hubungkan PostgreSQL/Netlify DB dan pastikan environment variable `NETLIFY_DATABASE_URL` tersedia untuk Functions. Alternatif: gunakan `DATABASE_URL`.
5. Jalankan SQL pada `netlify/database/migrations/001_petty_cash.sql` satu kali di database yang terhubung. Jika tabel sudah ada dari deploy lama, cocokkan skemanya dahulu dan jangan jalankan ulang tanpa memeriksa constraint.
6. Tambahkan environment variable `ADMIN_EMAIL` dengan email akun admin utama. Deploy ulang setelah mengubah environment variables.
7. Undang anggota Finance melalui Netlify Identity, lalu masukkan email mereka ke tabel `finance_team_members`. Role `admin` atau `finance` diperbolehkan; email pada `ADMIN_EMAIL` otomatis menjadi admin utama.
8. Buka `https://NAMA-SITE.netlify.app/admin` untuk dashboard admin.

## Status yang tersedia
`diajukan`, `ditinjau`, `perlu_revisi`, `disetujui`, `ditolak`, `dicairkan`, `selesai`.

Perubahan status dilakukan di server setelah verifikasi Netlify Identity dan izin Finance. Setiap perubahan disimpan di `petty_cash_activities`.

## Catatan integrasi penting
ZIP sumber yang diberikan berisi **hasil build/minified**, bukan source project asli maupun implementasi backend. Karena itu file frontend pemohon dipertahankan apa adanya, tetapi endpoint server-side asli yang membuat pengajuan, melacak pengajuan, mengunggah lampiran, dan mengelola anggota tim tidak ikut tersedia di ZIP tersebut. Dashboard admin di project ini memakai endpoint baru di `netlify/functions/` dan membaca tabel `petty_cash_requests`.

Agar perubahan status tampil pada halaman pelacakan pemohon secara otomatis, backend pengajuan/pelacakan pada aplikasi asli perlu diarahkan ke tabel dan endpoint yang sama. Jangan anggap integrasi pemohon-admin sudah live sebelum alur pengajuan baru diuji end-to-end di site Netlify. Jangan memasukkan kredensial database ke kode frontend atau repository.
