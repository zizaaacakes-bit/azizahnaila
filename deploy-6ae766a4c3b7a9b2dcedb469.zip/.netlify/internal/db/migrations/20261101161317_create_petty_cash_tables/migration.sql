CREATE TABLE "finance_team_members" (
	"id" serial PRIMARY KEY,
	"email" text NOT NULL UNIQUE,
	"name" text DEFAULT '' NOT NULL,
	"role" text DEFAULT 'finance' NOT NULL,
	"added_by" text DEFAULT '' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "petty_cash_activities" (
	"id" serial PRIMARY KEY,
	"request_id" integer NOT NULL,
	"actor_name" text NOT NULL,
	"actor_email" text DEFAULT '' NOT NULL,
	"action" text NOT NULL,
	"detail" text DEFAULT '' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "petty_cash_requests" (
	"id" serial PRIMARY KEY,
	"number" text NOT NULL UNIQUE,
	"tracking_hash" text NOT NULL,
	"requester_name" text NOT NULL,
	"requester_email" text NOT NULL,
	"requester_phone" text DEFAULT '' NOT NULL,
	"requester_role" text NOT NULL,
	"unit" text NOT NULL,
	"type" text NOT NULL,
	"category" text NOT NULL,
	"purpose" text NOT NULL,
	"description" text DEFAULT '' NOT NULL,
	"amount_requested" integer NOT NULL,
	"needed_date" date,
	"attachment_key" text,
	"attachment_name" text,
	"attachment_type" text,
	"status" text DEFAULT 'diajukan' NOT NULL,
	"amount_approved" integer,
	"settlement_amount" integer,
	"settlement_note" text DEFAULT '' NOT NULL,
	"message_to_requester" text DEFAULT '' NOT NULL,
	"handled_by_name" text,
	"handled_by_email" text,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE INDEX "activities_request_idx" ON "petty_cash_activities" ("request_id");--> statement-breakpoint
CREATE INDEX "requests_status_idx" ON "petty_cash_requests" ("status");--> statement-breakpoint
CREATE INDEX "requests_created_idx" ON "petty_cash_requests" ("created_at");--> statement-breakpoint
ALTER TABLE "petty_cash_activities" ADD CONSTRAINT "petty_cash_activities_request_id_petty_cash_requests_id_fkey" FOREIGN KEY ("request_id") REFERENCES "petty_cash_requests"("id") ON DELETE CASCADE;